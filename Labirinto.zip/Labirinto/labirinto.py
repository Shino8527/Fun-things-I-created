#geração do mapa feito pelo ChatGPT
import random
import pygame

class Maze:
    def __init__(self, width, height, square_size):
        self.width= width
        self.height= height
        self.square_size= square_size
        # Gera o labirinto
        self.labirinto = 0
        self.wall= pygame.transform.scale(pygame.image.load("square.jpg"), (square_size, square_size))
        self.end= pygame.transform.scale(pygame.image.load("finish_line.jpg"), (square_size, square_size))
        self.finished= False
        self.went_here= [(1, 1)]

    def generate_labirinto(self):
        # Inicializa o labirinto com paredes em todas as posições
        labirinto = [["x" for _ in range(self.width)] for _ in range(self.height)]

        # Define as posições de início (s) e fim (e)
        start = (1, 1)
        end = (self.width-2, self.height-2)
        labirinto[start[0]][start[1]] = "s"
        labirinto[end[0]][end[1]] = "e"

        # Função auxiliar para verificar se é seguro cavar um caminho
        def is_valid(x, y):
            if 0 < x < self.width-1 and 0 < y < self.height-1:
                # Conta espaços vazios ao redor
                empty_neighbors = sum(
                    1 for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]
                    if labirinto[x + dx][y + dy] == " "
                )
                return labirinto[x][y] == "x" and empty_neighbors <= 1
            return False

        # Cria um caminho inicial do começo ao fim
        def carve_path(x, y):
            directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
            random.shuffle(directions)
            for dx, dy in directions:
                nx, ny = x + dx, y + dy
                if is_valid(nx, ny):
                    labirinto[nx][ny] = " "
                    carve_path(nx, ny)

        labirinto[start[0]][start[1]] = "t"  # Marca a posição inicial como sitio onde ja esteve
        carve_path(*start)

        # Garante que a posição final esteja acessível
        labirinto[end[0]][end[1]] = "e"

        self.labirinto= labirinto
    
    def print_maze(self):
        for linha in self.labirinto:
            print("".join(linha))

    def solve(self, row, column, rowprevious, columnprevious):
        #função recursiva q procura o caminho tendo em conta q a posição anterior já foi vista
        if not self.finished:
            lst_around=  [(1,0),(0,1),(-1,0),(0,-1)]
            verify= False
            if rowprevious != "" and columnprevious != "": #primeira vez q usamos a função devemos colocar as "" nos 2 parametros
                verify= True

            for item in range (4):
                if self.verf(row+lst_around[item][0], column+lst_around[item][1]) and not self.finished:
                    bloco= self.labirinto[row+lst_around[item][0]][column+lst_around[item][1]]
                    if (row + lst_around[item][0] == rowprevious and column + lst_around[item][1] == columnprevious)\
                        or bloco== "x": #se for o anterior ou uma parede
                        pass
                    elif bloco == "e": #encontrou o fim
                        self.finished= True
                        break
                    else: #se for a primeira vez marca o sitio normalmente e segue a partir do mesmo
                        self.went_here.append((row+lst_around[item][0], column+lst_around[item][1]))
                        self.solve(row+lst_around[item][0], column+lst_around[item][1], row, column)

    def verf(self, row, column):
        try:
            item= self.labirinto[row][column]
            return True
        except IndexError:
            return False
        
    def mark_space(self,row,column, mark):
        self.labirinto[row][column]= mark

    def delete_wrong_ways(self):
        bifurcacoes= []
        lst_around= [(1,0),(0,1),(-1,0),(0,-1)]
        for item in self.went_here: #testa para todos os sitios onde o solver esteve
            caminhos=[] #coordenadas de caminhos por onde o solver foi numa bifurcação
            for test in self.went_here: 
            #verifica se algum dos outros sitios + uma direção, está na lista, ou seja, se existe outro sitio na lista "went_here" q seja adjacente ao "item"
                for direction in lst_around:
                    if item[0] + direction[0] == test[0] and item[1] + direction[1] == test[1]:
                        caminhos.append((test[0],test[1])) #adiciona as coordenadas do caminho testado à lista
            if len(caminhos) > 2:
                try:#tenta retirar o caminho de onde veio da lista de caminhos, se existir
                    caminhos.remove(self.went_here[self.went_here.index(item)-1])
                except:
                    pass
                bifurcacoes.append((item, caminhos)) #adiciona os caminhos por onde o solver foi

        if bifurcacoes != []:
            for caminho_apagado in bifurcacoes: #caminhos adjacentes à bifurcação
                if caminho_apagado[1][0] in self.went_here:
                #por vezes existem umas bifurcações dentro de outras e ao apagar o caminho errado das primeiras, a segunda deixa de existir na lista "went_here"
                    index_caminho_errado= self.went_here.index(caminho_apagado[1][0]) #index do 1º caminho errado
                    index_caminho_certo= self.went_here.index(caminho_apagado[1][-1]) #index do caminho certo
                    for item in range(index_caminho_certo - index_caminho_errado): #para o nr de itens entre o caminho certo e o errado, vai apagar esses itens
                        self.went_here.pop(index_caminho_errado)

        return bifurcacoes
    
    def mark_way_to_end(self):
        for item in self.went_here:
            self.mark_space(item[0], item[1], "t")