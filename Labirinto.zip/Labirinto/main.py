# -*- coding: utf-8 -*-
import pygame
from labirinto import Maze
pygame.init()
pygame.display.set_caption("Maze solver")

maze_width= 30
maze_height= maze_width
square_size= 25

#fullscreen, alt+f4 para sair
ScreenWidth= maze_width*square_size
ScreenHeight= maze_height*square_size
screen= pygame.display.set_mode((ScreenWidth,ScreenHeight))

maze= Maze(maze_width,maze_height,square_size) #largura, altura, tamanho do quadrado
maze.generate_labirinto()
maze.solve(1,1,"","")
maze.delete_wrong_ways()
maze.mark_way_to_end()

running=True
while running:
    screen.fill("black")

    for linha in range(len(maze.labirinto)):
        for col in range(len(maze.labirinto[linha])):
            if maze.labirinto[linha][col] == "x":
                screen.blit(maze.wall, (col*square_size, linha*square_size))
            elif maze.labirinto[linha][col] == "e":
                screen.blit(maze.end, (col*square_size, linha*square_size))
            elif maze.labirinto[linha][col] == "t":
                pygame.draw.rect(screen, "Green", pygame.rect.Rect(col*square_size, linha*square_size, square_size, square_size))
    
    for event in pygame.event.get():
       if event.type==pygame.QUIT:
           running=False
    
    pygame.display.update()
    
pygame.quit()