import random
import pygame

sprite_sheet= pygame.image.load("dice_sides.png")

def get_image_from_sprite_sheet(sprite_sheet, x, y, width, height):
    # Crear una nueva superficie para la sub-imagen
    image = pygame.Surface((width, height), pygame.SRCALPHA)
    # Blit (copiar) la sub-imagen desde la sprite sheet
    image.blit(sprite_sheet, (0, 0), (x, y, width, height))
    return image

class Dado:
    def __init__(self, screen, lados):
        self.screen= screen
        self.nrlados= lados
        self.number_shown= 1
        self.is_selected= 1
        #1 significa q está selecionado
        #-1 significa q não
        self.select_delay= 0
        self.size= 62
        self.hitbox= pygame.rect.Rect(0, 0, self.size, self.size)
        self.sprite= get_image_from_sprite_sheet(sprite_sheet, 10 + self.size*(self.number_shown-1), 10, self.size, self.size)

    def throw(self):
        lado_escolhido= random.randint(1, self.nrlados)
        self.number_shown= lado_escolhido
        self.update()
        self.rotate()
        
    def update(self):
        self.sprite= get_image_from_sprite_sheet(sprite_sheet, 10 + self.size*(self.number_shown-1), 10, self.size, self.size)
    
    def draw(self):
        #"desenhar" no ecrã o sprite correto do nr a mostrar de acordo com o seu nr
        if self.is_selected < 0:
            pygame.draw.rect(self.screen, (0, 255, 0), self.hitbox)
        self.screen.blit(self.sprite, self.hitbox)

    def rotate(self):
        self.sprite= pygame.transform.flip(self.sprite, random.randint(0,1), random.randint(0,1))

    def check_if_clicked(self):
        x, y= pygame.mouse.get_pos()
        mouse= pygame.rect.Rect(x, y, 1, 1)
        if pygame.Rect.colliderect(mouse, self.hitbox):
            return True
        
