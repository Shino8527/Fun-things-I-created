# -*- coding: utf-8 -*-
import pygame
import Dado
import Button

pygame.init()
pygame.display.set_caption("Yahtzee")

class Scoreboard:
    def __init__(self, screen):
        self.screen= screen
        self.item_list= ["1s", "2s", "3s", "4s", "5s", "6s", "3kind", "4kind", "Yahtzee", "fullhouse", "small_s", "large_s", "chance"]
        #lista de pontos
        #liga pequena
        #1s, 2s, 3s, 4s, 5s, 6s
        #o nr de pontos é decidido pela soma dos dados q contêm a escolha feita
        #exemplo: dados: 1 2 2 3 4 , escolheu 2, consegue 4 pontos

        #liga grande
        #3 of a kind, 4 of a kind -> pontos são a soma de todos os dados 
        #fullhouse-> 3 of a kind + 1 par, 25 pontos
        #small straight-> 1,2,3,4 or 2,3,4,5 or 3,4,5,6, 30 pontos
        #large straight-> 1,2,3,4,5 or 2,3,4,5,6, 40 pontos
        #chance-> soma o valor de todos os dados
        #Yahtzee-> 5 of a kind, 50 pontos

        self.hitbox= pygame.rect.Rect(ScreenWidth-300, 50, 150, 500)
        self.points=0
        self.buttons_list=[]

        for item in range(len(self.item_list)):
            self.buttons_list.append(Button.Button(self.screen, self.hitbox.x, self.hitbox.y + item*38, 250, 38, (255,255,255), str(self.item_list[item]) + ": ", 30))

    def count_number_list(self, number):
        lista=get_dados()
        nr=0
        for dado in range(len(lista)):
            if lista[dado].number_shown == number:
                nr+= 1
        return nr
    
    def sum_dados(self):
        lista=get_dados()
        nr=0
        for dado in range(len(lista)):
            nr+= lista[dado].number_shown
        return nr
    
    def rebuild_lista(self):
        lista=get_dados()
        lista_nova=[]
        for dado in range(len(lista)):
            lista_nova.append(lista[dado].number_shown)
        return lista_nova

    def Minor_league(self, number):
        item= str(number)+"s"
        if item in self.item_list:
            #a função conta quantos do number é q existem na lista de dados e 
            #os pontos são calculados pela multiplicação desse valor pelo number
            nr=self.count_number_list(number)
            self.points+= nr* number
            self.item_list.remove(item)
            return nr* number

    def OfAKind(self, kind_of_3_or_4):
        list_of_possibilities= []
        kind= str(kind_of_3_or_4)+"kind"
        if kind in self.item_list:
            for nr in range(1,7):
                list_of_possibilities.append(self.count_number_list(nr))
                #se contar q existem 3 nrs iguais na lista de dados

            if kind_of_3_or_4 in list_of_possibilities:
                self.item_list.remove(kind)
                self.points+= self.sum_dados()
                return self.sum_dados()
    
    def Yahtzee(self):
        list_of_possibilities= []
        for nr in range(1,7):
            list_of_possibilities.append(self.count_number_list(nr))
        if len(get_dados()) in list_of_possibilities:
            if "Yahtzee" in self.item_list:
                self.item_list.remove("Yahtzee")
                self.points+= 50
                return 50

    def Small_Straight(self):
        lista= self.rebuild_lista()
        if (3 in lista and 4 in lista) and (\
            (1 in lista and 2 in lista) or\
            (2 in lista and 5 in lista) or\
            (5 in lista and 6 in lista)):
            if "small_s" in self.item_list:
                self.item_list.remove("small_s")
                self.points+= 30
                return 30
    
    def Large_Straight(self):
        lista= self.rebuild_lista()
        if (2 in lista and 3 in lista and 4 in lista and 5 in lista) and\
            (1 in lista or 6 in lista):
            if "large_s" in self.item_list:
                self.item_list.remove("large_s")
                self.points+= 40
                return 40
    
    def Chance(self):
        self.points+= self.sum_dados()
        return self.sum_dados()

    def Fullhouse(self):
        list_of_possibilities= []
        for nr in range(1,7):
            list_of_possibilities.append(self.count_number_list(nr))
        if 2 in list_of_possibilities and 3 in list_of_possibilities and "fullhouse" in self.item_list:
            self.item_list.remove("fullhouse")
            self.points+= 25
            return 25

    def draw(self):
        for item in range(len(self.buttons_list)):
            self.buttons_list[item].draw()
    
    def Render_Points(self): #mostra os pontos no ecrã
        font = pygame.font.Font('freesansbold.ttf', 40)
        text = font.render("Total points: "+str(self.points), 1, (0,0,0))
        self.screen.blit(text, (100,100))


def get_dados():
    return lista_dados

def unselect_all():
    for dado in range(len(lista_dados)):
        dado_escolhido= lista_dados[dado]
        dado_escolhido.is_selected=1


#fullscreen, alt+f4 para sair
ScreenWidth= 1500
ScreenHeight= 800
midx= round(ScreenWidth/2)
midy= round(ScreenHeight/2)
screen= pygame.display.set_mode((ScreenWidth,ScreenHeight))

background= pygame.image.load("background.jpg")

button= Button.Button(screen, midx - 117, midy+ 200, 235, 40, (255, 255, 255), "Roll the dice", 40)

preto=(0,0,0)

lista_dados= []
for dado in range(5): #criar os dados e colocá-los dentro da lista de dados
    lista_dados.append(Dado.Dado(screen, 6))
    lista_dados[dado].hitbox.centerx= midx-300 + dado*145
    lista_dados[dado].hitbox.centery= midy
    lista_dados[dado].throw()

scoreboard= Scoreboard(screen)

running=True
while running:
    screen.fill(preto)
    screen.blit(background,(0,0))

    button.draw()

    scoreboard.draw()
    scoreboard.Render_Points()

    for dado in range(len(lista_dados)):
        lista_dados[dado].draw()
        if lista_dados[dado].select_delay > 0:
            lista_dados[dado].select_delay-=1
    
    for event in pygame.event.get():
       if event.type==pygame.QUIT:
           running=False
       elif event.type == pygame.KEYUP:
           pass
       elif event.type == pygame.MOUSEBUTTONDOWN and event.button==1: #carregou com o botão esquerdo
           if button.check_if_clicked():
                for dado in range(len(lista_dados)):
                    dado_escolhido= lista_dados[dado]
                    if dado_escolhido.is_selected > 0:
                        dado_escolhido.throw()
           else:
                for dado in range(len(lista_dados)):
                    dado_escolhido= lista_dados[dado]
                    if dado_escolhido.check_if_clicked():
                        dado_escolhido.is_selected*= -1
                        dado_escolhido.select_delay= 100

                for botao in range(13):
                    if scoreboard.buttons_list[botao].check_if_clicked():
                        if botao <= 5: #se o botão clicado for o 1s, 2s, 3s, 4s, 5s ou 6s
                            txt= scoreboard.Minor_league(botao+1)
                        elif botao == 6: #se for 3 of a kind
                            txt= scoreboard.OfAKind(3)
                        elif botao == 7: #se for 4 of a kind
                            txt= scoreboard.OfAKind(4)
                        elif botao == 8: #se for Yahtzee
                            txt= scoreboard.Yahtzee()
                        elif botao == 9: #se for fullhouse
                            txt= scoreboard.Fullhouse()
                        elif botao == 10: #se for small_s
                            txt= scoreboard.Small_Straight()
                        elif botao == 11: #se for large_s
                            txt= scoreboard.Large_Straight()
                        elif botao == 12: #se for chance
                            txt= scoreboard.Chance()
                        
                        scoreboard.buttons_list[botao].add_text( str(txt) )
                        unselect_all()

    pygame.display.update()
    
pygame.quit()