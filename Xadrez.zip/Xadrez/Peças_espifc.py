# -*- coding: utf-8 -*-
import pygame
from Peça_xadrez import*

sprite_sheet= pygame.image.load("png-transparent-chess-piece-pin-knight-chess-pieces-game-white-king-removebg-preview.png")


def get_image_from_sprite_sheet(sprite_sheet, x, y, width, height):
    # Crear una nueva superficie para la sub-imagen
    image = pygame.Surface((width, height), pygame.SRCALPHA)
    # Blit (copiar) la sub-imagen desde la sprite sheet
    image.blit(sprite_sheet, (0, 0), (x, y, width, height))
    return image


class Rei(Peca_xadrez):
    def set_pieces(self):
        self.pecabranca= get_image_from_sprite_sheet(sprite_sheet, 0, 0, 45, 45)
        self.pecapreta= get_image_from_sprite_sheet(sprite_sheet, 0, 40, 43, 43)
        self.can_castle= True
        self.in_check = False

    def check_checks(self, lista, fila_rei, coluna_rei):
        #ver se há algum cavalo na posição de dar check ao rei
        cavalo_possible_checks= [(1,-2), (-1,-2), (2,1), (2,-1), (1,2), (-1,2), (-2,1), (-2,-1)]
        for possibility in range ( len(cavalo_possible_checks) ):
            xrelativo, yrelativo = cavalo_possible_checks[possibility]
            try:
                if fila_rei + xrelativo >= 0 and coluna_rei + yrelativo >= 0:
                    if lista[fila_rei + xrelativo][coluna_rei + yrelativo] != "":
                        if lista[fila_rei + xrelativo][coluna_rei + yrelativo].tipo == "Cavalo" and lista[fila_rei + xrelativo][coluna_rei + yrelativo].team != lista[fila_rei][coluna_rei].team:
                                return "check"
            except IndexError:
                pass

        list_ways_to_check= [(1,0),(-1,0),(0,1),(0,-1),(1,-1),(-1,1),(1,1),(-1,-1)]
        if lista[fila_rei][coluna_rei].tipo != "Rei": #confirmar q as coordenadas do rei estão corretas
            return []
    
        for direcao in range (8):#verificar todas as direções
            #começa pela quadricula do rei e vai somando a direção para analisar todas as quadriculas
            filaverf= fila_rei
            colunaverf= coluna_rei
            xrelativo, yrelativo = list_ways_to_check[direcao]
            c= True #manter o ciclo para verificar em q direções está uma peça inimiga a ver o rei 
        #(esta parte é só dos bispos, torres e rainhas)
            while c:
                if filaverf + yrelativo >= 0 and colunaverf + xrelativo >= 0: #se continuamos dentro da lista ao analisar a posição q queremos
                    #analisa nessa direção
                    filaverf+= yrelativo
                    colunaverf+= xrelativo
                    try:
                        if lista[filaverf][colunaverf] != "": #se a posição a analisada n está vazia
                            if lista[filaverf][colunaverf].team == lista[fila_rei][coluna_rei].team: 
                                #há uma peça no caminho e é da equipa do rei, logo o rei está protegido
                                c= False

                            else: #a peça q está lá é da equipa inimiga
                                if xrelativo == 0 or yrelativo == 0: #está a "ver" o rei na vertical ou horizontal em relação ao rei
                                    if lista[filaverf][colunaverf].tipo == "Torre" or lista[filaverf][colunaverf].tipo == "Rainha": 
                                        #se for uma ameaça
                                        return "check"
                                    else:
                                        c= False
                                elif abs(xrelativo - yrelativo) == 2 or abs(xrelativo - yrelativo) == 0: #está a ver o rei numa diagonal
                                    #e.g. abs(1-1)= 0 ou abs(-1-1)= 2
                                    if lista[filaverf][colunaverf].tipo == "Bispo" or lista[filaverf][colunaverf].tipo == "Rainha":
                                        #se for uma ameaça
                                        return "check"
                                    else:
                                        c= False
                                    
                    except IndexError: #chegou-se ao fim da lista
                        c= False

                else: #se a fila ou coluna q estamos a verificar for negativo, passa se há proxima direção pq estamos fora ad lista
                    c= False

        #verificar se há algum peão a dar check ao rei
        if lista[fila_rei][coluna_rei].team == "white":
            yrelativo= -1
        else:
            yrelativo= 1

        try:
            if fila_rei - 1 >= 0 and coluna_rei - 1 >= 0:
                if (lista[fila_rei + yrelativo][coluna_rei + 1].tipo == "Peao" and lista[fila_rei + yrelativo][coluna_rei + 1].team != lista[fila_rei][coluna_rei].team ) \
                    or (lista[fila_rei + yrelativo][coluna_rei - 1].tipo == "Peao" and lista[fila_rei + yrelativo][coluna_rei - 1].team != lista[fila_rei][coluna_rei].team ):
                    return "check"
        except:
            pass

        
class Rainha(Peca_xadrez):
    def set_pieces(self):
        self.pecabranca= get_image_from_sprite_sheet(sprite_sheet, 40, 0, 45, 45)
        self.pecapreta= get_image_from_sprite_sheet(sprite_sheet, 40, 40, 43, 43)
        
class Torre(Peca_xadrez):
    def set_pieces(self):
        self.pecabranca= get_image_from_sprite_sheet(sprite_sheet, 167, 0, 45, 45)
        self.pecapreta= get_image_from_sprite_sheet(sprite_sheet, 167, 40, 43, 43)
        self.can_castle= True
        
class Bispo(Peca_xadrez):
    def set_pieces(self):
        self.pecabranca= get_image_from_sprite_sheet(sprite_sheet, 83, 0, 45, 45)
        self.pecapreta= get_image_from_sprite_sheet(sprite_sheet, 83, 40, 43, 43)
        
class Cavalo(Peca_xadrez):
    def set_pieces(self):
        self.pecabranca= get_image_from_sprite_sheet(sprite_sheet, 125, 0, 45, 45)
        self.pecapreta= get_image_from_sprite_sheet(sprite_sheet, 125, 40, 43, 43)
        
class Peao(Peca_xadrez):
    def set_pieces(self):
        self.pecabranca= get_image_from_sprite_sheet(sprite_sheet, 208, 0, 45, 45)
        self.pecapreta=  get_image_from_sprite_sheet(sprite_sheet, 208, 40, 43, 43)
    
    def check_promotion(self): #verifica se a peça escolhida está na sua ultima posição possivel
        if (self.team == "white" and self.pos[1] <= 139) or (self.team == "black" and self.pos[1] >= 692):
            return True