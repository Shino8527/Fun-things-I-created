# -*- coding: utf-8 -*-
import pygame

dama_normal_branca= pygame.image.load("dama_normal_branca.png")
dama_normal_preta= pygame.image.load("dama_normal_preta.png")
dama_branca= pygame.image.load("dama_branca.png")
dama_preta= pygame.image.load("dama_preta.png")
class Peca:
    def __init__(self, screen, pos, size, state, team):
        self.screen= screen
        self.pos= pos
        self.state= state
        self.team= team
        self.size= size
        self.is_selected= False
        self.color= (0,255,0) #cor de estar selecionado
        self.hitbox= pygame.Rect(0 , 0, size, size)
        self.hitbox.center= (pos[0],pos[1])
        self.selectable= True
    
        
    def draw(self): #desenhar a peça, de acordo com o seu tipo e equipa
        if self.state== "normal":
            if self.team=="white":
                self.screen.blit(dama_normal_branca, self.hitbox)
            else:
                self.screen.blit(dama_normal_preta, self.hitbox)
                
        else:
            if self.team== "white":
                self.screen.blit(dama_branca, self.hitbox)
            else:
                self.screen.blit(dama_preta, self.hitbox)
        
    def set_state(self, what):
        self.state= what
    
    def get_pos(self):
        return self.pos
    
    def set_pos(self, posicaofinal):
        self.hitbox.center= posicaofinal
        self.pos= posicaofinal
    
    def check_if_selected(self, mouse_pos):
        mouse= pygame.Rect(0 , 0, 1, 1)
        mouse.center= mouse_pos
        if pygame.Rect.colliderect(self.hitbox, mouse):
            return True
        else: 
            return False
        
    def selected(self): #mostra q está selecionada
        pygame.draw.rect(self.screen, self.color, self.hitbox)
        
    def check_promotion(self): #verifica se a peça escolhida está na sua ultima posição possivel
        if (self.team == "white" and self.pos[1] <= 139) or (self.team == "black" and self.pos[1] >= 692):
            return True
        else: 
            return False
            
def create_white(self): #criar uma peça branca
    return Peca(self.screen, (0, 0), 30, "normal", "white")

def create_black(self): #criar uma peça preta
    return Peca(self.screen, (0, 0), 30, "normal", "black")   