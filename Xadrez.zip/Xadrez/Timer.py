import math

def show_timer(nrsegundos): #mostrar o tempo dos jogadores em "mins:segundos"
    minutos= math.floor(nrsegundos/60)
    if minutos <= 0:
        minstxt= ""
    else:
        minstxt= str(minutos) + ":"
    segundos = nrsegundos - minutos*60
    if segundos <= 10:
        segundos = "0" + str(round(nrsegundos - minutos*60, 2))
    else:
        segundos= round(nrsegundos - minutos*60)
    if nrsegundos <= 0:
        minutos = 0
        segundos = "00:00"
    return minstxt + str(segundos)