# -*- coding: utf-8 -*-
import math
from Peça import*
from Peça_xadrez import*
from Peças_espifc import*

class Tabuleiro:
    def __init__(self, screen, nrcolunas, nrfilas, tamquadricula, postabuleiro):
        self.screen= screen
        self.nrcolunas= nrcolunas
        self.nrfilas= nrfilas
        self.tamquadricula= tamquadricula #tamanho das quadriculas
        self.postabuleiro= postabuleiro #ppsição em q o topo superior esquerdo do tabuleiro está a ser desenhado
        
        self.list= [] #inicializar a lista
        for filas in range(self.nrfilas): #fazer a matriz q serve de tabuleiro
            fila=[]
            self.list.append(fila)
            for colunas in range(self.nrcolunas):
                self.list[filas].append("")
        
        
    def populate_damas(self): #popular a lista (self.list) com as damas nas posições certas
        meiaquad= math.floor(self.tamquadricula/2)
        for filas in range(3): #criador das peças pretas
            blackFirst= False
            y= filas*self.tamquadricula + self.postabuleiro[1] + meiaquad #definir o y
            if filas % 2 == 0:
                blackFirst= True #o primeiro quadrado da fila é preto
            aumcoluna=0
            for quadricula in range (self.nrcolunas):
                if quadricula % 2 == 0:
                    x= quadricula*self.tamquadricula + self.postabuleiro[0] + meiaquad #definir o x
                    if blackFirst: #se a preta for a primeira
                        x+= self.tamquadricula #mover uma quadricula para o lado direito
                        aumcoluna=1 #e colocar na lista uma posição ao lado tbm
                    peca_criada= Peca(self.screen, (x, y), 30, "normal", "black") #criar o objeto Peça preta
                    self.list[filas][quadricula+aumcoluna]=peca_criada #colocar o objeto na lista na posição certa
                    
        for filas in range(3): #criador das peças brancas
            blackFirst= False
            y= filas*self.tamquadricula + self.postabuleiro[1] + meiaquad + self.tamquadricula*5 #definir o y
            #y=0
            #x=0
            if filas % 2 != 0:
                blackFirst= True
            aumcoluna=0
            for quadricula in range (self.nrcolunas):
                if quadricula % 2 == 0:
                    x= quadricula*self.tamquadricula + self.postabuleiro[0] + meiaquad #definir o x
                    if blackFirst:
                        x+= self.tamquadricula
                        aumcoluna=1
                    #print(str(x)+ "  "+ str(y))
                    peca_criada= Peca(self.screen, (x, y), 30, "normal", "white") #criar o objeto Peça
                    self.list[filas+5][quadricula+aumcoluna]= peca_criada
    
    def inside_tabuleiro(self, coluna, fila): #verifica se a coluna e a fila são maiores q zero para as peças n saltarem para fora do tabuleiro
        if coluna >= 0 and fila >= 0:
            return True
        else:
            return False
    def piece_move(self, posinicial, posfinal, pecatype):
        filaselec, colunaselec= posfinal #posição destino
        filain, colunain= posinicial #posição em q a peça está agora
        self.list[filaselec][colunaselec]= self.list[filain][colunain]
        self.list[filain][colunain]= ""


    def dama_move(self, posinicial, posfinal, pecatype): #mover a dama no tabuleiro
        filaselec, colunaselec= posfinal #posição destino
        filain, colunain= posinicial #posição em q a peça está agora
        peca= self.list[filain][colunain] #peça selecionada para ser mexida
        if ( (peca.team == "white" and filain < filaselec) or (peca.team != "white" and filain > filaselec) ) and pecatype== "normal":
            #se a peça branca ou a preta estiverem a andar para trás, respetivamente
            return "" #só para sair da função
        
        if peca.state == "dama": #para as damas
            if ( abs(filain - filaselec) == abs(colunain - colunaselec) ): #está a andar na diagonal?
                pass #sim
            else: #se não
                return "" #sai da função
        
        try: #caso haja um index error de a peça tentar ir para fora do tabuleiros
            if self.list[filaselec][colunaselec] == "" and self.inside_tabuleiro(colunaselec,filaselec): #se o sitio selecionado estiver vazio
                #print("movimento normal")
                #print(colunaselecionada, filaselecionada)
                
                self.list[filaselec][colunaselec]= self.list[filain][colunain]
                
                self.list[filain][colunain]= "" #apagar a peça inicial
                
            
            else: #o sitio selecionado n estava vazio
                if self.list[filaselec][colunaselec].team != peca.team:
                    #se no quadrado de destino houver uma peça inimiga, verifica as seguintes condições
                    
                    if peca.pos[1] > self.list[filaselec][colunaselec].pos[1]:
                         #se o y da peça movida for maior q a q está a ser comida, estamos a ir para cima
                         
                         if peca.pos[0] > self.list[filaselec][colunaselec].pos[0]:
                             #se o x da peça movida for maior q a q está a ser comida, estamos a ir para a esquerda
                             
                             if self.list[filaselec-1][colunaselec-1]== "" and self.inside_tabuleiro(colunaselec-1,filaselec-1):
                                 #se a posição atrás da q está a ser comida estiver livre
                                 
                                 #"peça comida em cima à esquerda"
                                 self.list[filaselec][colunaselec]= ""
                                 
                                 filaselec-=1
                                 colunaselec-=1
                                 self.list[filaselec][colunaselec]= self.list[filain][colunain]
                                     
                                 self.list[filain][colunain]="" #apagar a peça inicial
                                     
                                 
                         else: #o x da peça movida é menor q a q está a ser comida, estamos a ir para a direita
                             if self.list[filaselec-1][colunaselec+1]== "" and self.inside_tabuleiro(colunaselec-1,filaselec+1):
                                 #se a posição atrás da q está a ser comida estiver livre
                                 
                                 #"peça comida em cima à direita"
                                 self.list[filaselec][colunaselec]= "" #apagar a q foi comida
                                 
                                 #e mover a peça escolhida para trás da comida
                                 filaselec-=1
                                 colunaselec+=1
                                 self.list[filaselec][colunaselec]= self.list[filain][colunain]
                                     
                                 self.list[filain][colunain]="" #apagar a peça inicial
                                 
                             
                    else: #estamos a ir para baixo
                         if peca.pos[0] > self.list[filaselec][colunaselec].pos[0]:
                             #se o x da peça movida for maior q a q está a ser comida, estamos a ir para a esquerda
                             
                             if self.list[filaselec+1][colunaselec-1]== "" and self.inside_tabuleiro(colunaselec+1,filaselec-1):
                                 #se a posição atrás da q está a ser comida estiver livre
                                 
                                 #"peça comida em baixo à esquerda"
                                 self.list[filaselec][colunaselec]= ""
                                 
                                 filaselec+=1
                                 colunaselec-=1
                                 self.list[filaselec][colunaselec]= self.list[filain][colunain]
                                     
                                 self.list[filain][colunain]="" #apagar a peça inicial
                                     
                                 
                         else: #o x da peça movida é menor q a q está a ser comida, estamos a ir para a direita
                             if self.list[filaselec+1][colunaselec+1]== "" and self.inside_tabuleiro(colunaselec+1,filaselec+1):
                                 #se a posição atrás da q está a ser comida estiver livre
                                 
                                 #"peça comida em baixo à direita"
                                 self.list[filaselec][colunaselec]= "" #apagar a q foi comida
                                 
                                 #e mover a peça escolhida para trás da comida
                                 filaselec+=1
                                 colunaselec+=1
                                 self.list[filaselec][colunaselec]= self.list[filain][colunain]
                                     
                                 self.list[filain][colunain]="" #apagar a peça inicial
        except IndexError:
            pass
        
        
    def populate_xadrez(self): #popular a lista com as peças de xadrez
        #Reis
        self.list[7][4]= Rei(self.screen, (0,0), 40, "Rei", "white")
        self.list[0][4]= Rei(self.screen, (0,0), 40, "Rei", "black")
        #Rainhas
        self.list[7][3]= Rainha(self.screen, (0,0), 40, "Rainha", "white")
        self.list[0][3]= Rainha(self.screen, (0,0), 40, "Rainha", "black")
        #Torres
        self.list[0][0]= Torre(self.screen, (0,0), 40, "Torre", "black")
        self.list[0][7]= Torre(self.screen, (0,0), 40, "Torre", "black")
        self.list[7][0]= Torre(self.screen, (0,0), 40, "Torre", "white")
        self.list[7][7]= Torre(self.screen, (0,0), 40, "Torre", "white")
        #Bispos
        self.list[0][2]= Bispo(self.screen, (0,0), 40, "Bispo", "black")
        self.list[0][5]= Bispo(self.screen, (0,0), 40, "Bispo", "black")
        self.list[7][2]= Bispo(self.screen, (0,0), 40, "Bispo", "white")
        self.list[7][5]= Bispo(self.screen, (0,0), 40, "Bispo", "white")
        #Cavalos
        self.list[0][1]= Cavalo(self.screen, (0,0), 40, "Cavalo", "black")
        self.list[0][6]= Cavalo(self.screen, (0,0), 40, "Cavalo", "black")
        self.list[7][1]= Cavalo(self.screen, (0,0), 40, "Cavalo", "white")
        self.list[7][6]= Cavalo(self.screen, (0,0), 40, "Cavalo", "white")
        #Peões
        for peao in range (8):
            self.list[6][peao]= Peao(self.screen, (0,0), 40, "Peao", "white")
            self.list[1][peao]= Peao(self.screen, (0,0), 40, "Peao", "black")

        
    def distancia_pontos(self,p1,p2):
        distancia= math.sqrt( (p1[0]-p2[0])**2 + (p1[1]-p2[1])**2)
        return distancia
    
    def nada_no_caminho_bispo(self, posinicial, posfinal):
        filaselec, colunaselec= posfinal #posição destino
        filain, colunain= posinicial #posição em q a peça está agora
        if filain > filaselec: #se estivermos a mexer de baixo para cima no tabuleiro
            yrelativo= -1 #tem de se verificar para cima na lista, ou seja, o contrário do q se vê realmente
        else:
            yrelativo= 1

        if colunain > colunaselec: #estamos a ir PARA a esquerda
            xrelativo= -1
        else: #estamos a ir PARA a direita
            xrelativo= 1

        c= True #ciclo para verificar se chegamos à ultima posição sem encontrar nenhuma peça
        while c:
            filain+= yrelativo
            colunain+= xrelativo
            if self.list[filain][colunain] != "" and filain != filaselec and colunain != colunaselec: #se a quadricula q estamos a verificar tem uma peça lá, existe uma peça no caminho
                return False
            
            elif filain == filaselec and colunain == colunaselec: #se chegamos à ultima posição, sai do ciclo
                c= False
        
        return True

    def xadrez_move(self, posinicial, posfinal, pecatype):
        piece_can_be_moved= False
        filaselec, colunaselec= posfinal #posição destino
        filain, colunain= posinicial #posição em q a peça está agora
        peca= self.list[filain][colunain] #peça selecionada para ser mexida
        try: #uma peça n pode comer outra da mesma equipa
            if peca.team == self.list[filaselec][colunaselec].team:
                return False
        except AttributeError:
            pass
        
        try: 
            if pecatype == "Rei":
                if  self.distancia_pontos(posfinal, posinicial) < 1.5:
                    if self.list[filaselec][colunaselec] == "": #se o rei quer mexer se para um sitio q está vazio
                        piece_can_be_moved= True
                    elif self.list[filaselec][colunaselec].team == self.list[filain][colunain].team or not self.inside_tabuleiro(colunaselec,filaselec):
                        #se o rei quer ir para o sitio onde está uma peça da sua equipa ou para fora do tabuleiro
                        return False
                    elif self.list[filaselec][colunaselec].team != self.list[filain][colunain].team: #se está uma peça inimiga no sitio selecionado
                        piece_can_be_moved= True

                else: #tenta o castle
                    if filain == filaselec: #se o movimento for na mesma fila
                        try:
                            if colunaselec > colunain: #se a a torre selecionada for a da direita
                                c= True
                                pos_verf= 0 #posição verificada
                                while c:
                                    pos_verf += 1
                                    if self.list[filain][colunain + pos_verf] != "" and colunain + pos_verf != colunaselec:
                                        #se houver uma peça no caminho para de continuar tentar fazer castle
                                        return False
                                    elif colunain + pos_verf == colunaselec: #se estamos na ultima posição (da torre)
                                        c= False

                                if self.list[filain][colunain].can_castle and self.list[filain][colunain + 3].can_castle: 
                                    #se ambas as peças poderem fazer castle
                                    #colocar o rei na nova posição
                                    self.list[filain][colunain + 2] = self.list[filain][colunain]
                                    self.list[filain][colunain] = ""
                                    #colocar a torre na nova posição
                                    self.list[filain][colunain + 1] = self.list[filain][colunain + 3]
                                    self.list[filain][colunain + 3] = ""
                                    return True
                                
                            else: #se a a torre selecionada for a da esquerda
                                c= True
                                pos_verf= 0 #posição verificada
                                while c:
                                    pos_verf -= 1
                                    if self.list[filain][colunain + pos_verf] != "" and colunain + pos_verf != colunaselec:
                                        #se houver uma peça no caminho para de continuar tentar fazer castle
                                        return False
                                    elif colunain + pos_verf == colunaselec: #se estamos na ultima posição (da torre)
                                        c= False

                                if self.list[filain][colunain].can_castle and self.list[filain][colunain - 4].can_castle: 
                                    #se ambas as peças poderem fazer castle
                                    #colocar o rei na nova posição
                                    self.list[filain][colunain - 2] = self.list[filain][colunain]
                                    self.list[filain][colunain] = ""
                                    #colocar a torre na nova posição
                                    self.list[filain][colunain - 1] = self.list[filain][colunain - 4]
                                    self.list[filain][colunain - 4] = ""
                                    return True
                        except AttributeError: #n há uma torre nos sitios onde deveria estar uma torre para fazer o castle
                            return False

            elif pecatype == "Rainha":
                if ( abs(filain - filaselec) == abs(colunain - colunaselec) ): #está a andar na diagonal?
                    #sim
                    if self.nada_no_caminho_bispo(posinicial, posfinal):
                        if  self.list[filaselec][colunaselec]== "" or self.list[filaselec][colunaselec].team != self.list[filain][colunain].team:
                            piece_can_be_moved= True
                
                elif filain == filaselec and colunain != colunaselec: #mexer na horizontal
                    #verificar q n há nenhuma peça no caminho
                    if colunain < colunaselec: #ou vai nesta direção
                        for colunaverificada in range (colunain+1, colunaselec):
                            if self.list[filain][colunaverificada] != "": #se houver uma peça no caminho
                                return False
                    else: #ou vai nesta direção
                        for colunaverificada in range (colunaselec+1, colunain):
                            if self.list[filain][colunaverificada] != "": #se houver uma peça no caminho
                                return False
                    piece_can_be_moved= True
                elif colunain == colunaselec and filain != filaselec: #mexer na vertical
                    #verificar q n há nenhuma peça no caminho
                    if filain < filaselec: #ou vai nesta direção
                        for filaverificada in range (filain+1, filaselec):
                            if self.list[filaverificada][colunaselec] != "": #se houver uma peça no caminho
                                return False
                    else: #ou vai nesta direção
                        for filaverificada in range (filaselec+1, filain):
                            if self.list[filaverificada][colunaselec] != "": #se houver uma peça no caminho
                                return False
                    piece_can_be_moved= True

            elif pecatype == "Torre":
                if filain == filaselec and colunain != colunaselec: #mexer na horizontal
                    #verificar q n há nenhuma peça no caminho
                    if colunain < colunaselec: #ou vai nesta direção
                        for colunaverificada in range (colunain+1, colunaselec):
                            if self.list[filain][colunaverificada] != "": #se houver uma peça no caminho
                                return False
                    else: #ou vai nesta direção
                        for colunaverificada in range (colunaselec+1, colunain):
                            if self.list[filain][colunaverificada] != "": #se houver uma peça no caminho
                                return False
                    piece_can_be_moved= True
                elif colunain == colunaselec and filain != filaselec: #mexer na vertical
                    #verificar q n há nenhuma peça no caminho
                    if filain < filaselec: #ou vai nesta direção
                        for filaverificada in range (filain+1, filaselec):
                            if self.list[filaverificada][colunaselec] != "": #se houver uma peça no caminho
                                return False
                    else: #ou vai nesta direção
                        for filaverificada in range (filaselec+1, filain):
                            if self.list[filaverificada][colunaselec] != "": #se houver uma peça no caminho
                                return False
                    piece_can_be_moved= True

            elif pecatype == "Bispo":
                if ( abs(filain - filaselec) == abs(colunain - colunaselec) ): #está a andar na diagonal?
                    #sim
                    if self.nada_no_caminho_bispo(posinicial, posfinal): #se n há nd no caminho do bispo
                        if  self.list[filaselec][colunaselec]== "" or self.list[filaselec][colunaselec].team != self.list[filain][colunain].team:
                            #se o espaço selecionado está vazio ou tem uma peça inimiga, o bispo pode ir para lá
                            piece_can_be_moved= True
                else: #se não
                    return False #sai da função
                
            elif pecatype == "Cavalo":
                cavalo_possible_movements= [(1,-2), (-1,-2), (2,1), (2,-1), (1,2), (-1,2), (-2,1), (-2,-1)]
                #movimento relativo do cavalo
                xrelativo= filain - filaselec
                yrelativo= colunain - colunaselec
                if (xrelativo,yrelativo) in cavalo_possible_movements: #se esse movimento é um L
                    if self.list[filaselec][colunaselec] != "" and self.list[filaselec][colunaselec].team == self.list[filain][colunain].team:
                        #se existir uma peça na casa selecionada e é da mesma equipa do cavalo, o cavalo n pode ir para lá
                        return False
                    else:
                        piece_can_be_moved= True

            elif pecatype == "Peao":
                if (self.list[filaselec+2][colunaselec] == self.list[filain][colunain] and filain == 6 and peca.team == "white")\
                or (self.list[filaselec-2][colunaselec] == self.list[filain][colunain] and filain == 1 and peca.team == "black"):
                    #na primeira vez q o peão se mexe, ele pode mexer se duas "casas" à sua frente
                    piece_can_be_moved= True
                elif ( (filain-1 == filaselec and peca.team == "white")\
                or (filain+1 == filaselec and peca.team == "black") ): #se o peao quer mexer se só uma casa para a frente
                    if colunain == colunaselec and self.list[filaselec][colunaselec] == "": #se o espaço está vazio
                        piece_can_be_moved= True
                    elif colunain != colunaselec and abs(colunain-colunaselec) == 1: #se está a tentar mexer se só uma casa na diagonal
                        if self.list[filaselec][colunaselec] == "" or self.list[filaselec][colunaselec].team == self.list[filain][colunain].team:
                            #se o espaço está vazio ou está uma peça da equipa do peão, este n pode ir para a pos selecionada
                            return False
                        else:
                            if self.list[filaselec][colunaselec].team != self.list[filain][colunain].team: #se houver lá uma peça inimiga, o peão pode comê la
                                piece_can_be_moved= True
            else:
                print("peça n reconhecida")
        
        except IndexError:
            return False
        
        if piece_can_be_moved:
            piece_taken = self.list[filaselec][colunaselec]
            if (pecatype == "Torre" or pecatype == "Rei"):
                if self.list[filain][colunain].can_castle != False:
                    self.list[filain][colunain].can_castle= False
            self.list[filaselec][colunaselec]= self.list[filain][colunain]
            self.list[filain][colunain]= ""
            return True, piece_taken
    
    def check_if_king_in_check(self, lista):
        for fila in range (len(lista)):
            for coluna in range (len(lista[fila])):
                try:
                    if self.list[fila][coluna].tipo == "Rei":
                        if self.list[fila][coluna].in_check:
                            return self.list[fila][coluna].team
                except AttributeError:
                    pass
        return False
    
    def get_emptyspace(self):
        count= 10
        for fila in range (len(self.list)):
            for coluna in range (len(self.list[fila])):
                if self.list[fila][coluna] == "":
                    if count <= 0:
                        return [fila,coluna]
                    else:
                        count-=1

    def check_checkmate(self, filarei, colunarei):
        search_checks = [(0,0), (0,1), (0,-1), (1,0), (1,1), (1,-1), (-1,0), (-1,1), (-1,-1)]
        count= 0
        if self.list[filarei][colunarei].in_check:
            for pos in range (9):
                test_list= self.list
                test_list[filarei + search_checks[pos][0]][colunarei + search_checks[pos][1]] = self.list[filarei][colunarei]
                if self.check_if_king_in_check(test_list) != False:
                    count+= 1
        if count == 9:
            return "checkmate"