# -*- coding: utf-8 -*-
import pygame
import math
from Peça_xadrez import *
from Peças_espifc import *
from Tabuleiro import *
from Timer import *
import copy 

pygame.init()
pygame.display.set_caption("Xadrez")

background_sprite= pygame.image.load("Board.jpg")


def mousepos():
    return pygame.mouse.get_pos()

def Render_Text(what, color, where, additional_text, lettersize): #mostra o q for na srceen
    font = pygame.font.Font('freesansbold.ttf', lettersize)
    text = font.render(additional_text+what, 1, color)
    screen.blit(text, where)
    
def tradutor_lista_coordreal(coluna, fila):
    #print(coluna, fila)
    #calcular as coordenadas reais no tabuleiro
    coluna*= tamquadricula
    coluna+= postabuleiro[0]- tamquadricula/2
    fila*= tamquadricula
    fila+= postabuleiro[1]- tamquadricula/2
    
    coluna= math.floor(coluna)
    fila= math.floor(fila)
    
    #print(coluna, fila)
    return [coluna,fila]

def distancia_pontos(p1,p2):
    distancia= math.sqrt( (p1[0]-p2[0])**2 + (p1[1]-p2[1])**2)
    return distancia

def posicao_in_tabuleiro(tamquadricula, postabuleiro, mouse_pos):
    #definir exatamente em q quadricula é q o rato está
    x, y= mouse_pos[0]-postabuleiro[0] , mouse_pos[1]-postabuleiro[1]
    
    coluna= math.floor(x/tamquadricula)
    if x%tamquadricula > 0:
        coluna+=1
    
    fila= math.floor(y/tamquadricula)
    if  y%tamquadricula > 0:
        fila+=1
     
    return [coluna,fila]

def all_eliminated_1team(lista):
    team_branca=0
    team_preta=0
    for fila in range(8):# verifica para todas as filas aka listas dentro da lista principal
        for coluna in range(8):
            if tabuleiro.list[fila][coluna] != "":
                if tabuleiro.list[fila][coluna].team == "white":
                    team_branca+=1
                else:
                    team_preta+=1
    if team_branca == 0 or team_preta == 0:
        return True
    else:
        return False
    

def show_possible_promotions():
    caixa= pygame.rect.Rect(0, 0, 100, 80)
    caixa.right= ScreenWidth
    pygame.draw.rect(screen, white, caixa)
    Render_Text("Q= Queen", preto, (caixa.left, caixa.top), "", 20)
    Render_Text("R= Rook", preto, (caixa.left, caixa.top+20), "", 20)
    Render_Text("H= Horse", preto, (caixa.left, caixa.top+40), "", 20)
    Render_Text("B= Bishop", preto, (caixa.left, caixa.top+60), "", 20)

def king_check():
    caixa= pygame.rect.Rect(0, 0, 122, 40)
    caixa.centerx= midx
    pygame.draw.rect(screen, (255,0,0), caixa)
    Render_Text("Check", preto, (caixa.left, caixa.top+2), "", 40)

def mostrar_tabuleiro_na_consola(tabuleiro):
    peçasbrancas= { "Cavalo": "♘", "Rei": "♔", "Rainha": "♕", "Torre": "♖", "Bispo": "♗", "Peao": "♙"}
    peçaspretas= { "Cavalo": "♞", "Rei": "♚", "Rainha": "♛", "Torre": "♜", "Bispo": "♝", "Peao": "♟"}
    linha= ""
    print()
    for fila in range ( len(tabuleiro) ):
        linha= ""
        for coluna in range ( len(tabuleiro[fila]) ):
            if tabuleiro[fila][coluna] == "":
                linha+= " " + " | "
            else:
                if tabuleiro[fila][coluna].team == "white":
                    linha+= peçasbrancas[ tabuleiro[fila][coluna].tipo ] + " | "
                else:
                    linha+= peçaspretas[ tabuleiro[fila][coluna].tipo ] + " | "
        print(linha)
    return tabuleiro

def endscreen_by_time(winning_team):
    txt= winning_team + " wins by time!!!"
    caixa= pygame.rect.Rect(0, 0, 410, 40)
    caixa.center= (midx, midy)
    pygame.draw.rect(screen, white, caixa)
    Render_Text(txt, preto, (caixa.left, caixa.top), "", 40)

def endscreen_by_checkmate(king_not_in_checkmate):
    txt= king_not_in_checkmate + " wins by checkmate!!!"
    caixa= pygame.rect.Rect(0, 0, 410, 40)
    caixa.center= (midx, midy)
    pygame.draw.rect(screen, white, caixa)
    Render_Text(txt, preto, (caixa.left, caixa.top), "", 40)
    
#fullscreen, alt+f4 para sair
ScreenWidth= 832
ScreenHeight= 800
midx= round(ScreenWidth/2)
midy= round(ScreenHeight/2)
screen= pygame.display.set_mode((ScreenWidth,ScreenHeight))

preto=(0,0,0)
white=(255,255,255)

#definir o tabuleiro
postabuleiro= (100,100)
tamquadricula= 79
tabuleiro= Tabuleiro(screen, 8, 8, tamquadricula, postabuleiro)
tabuleiro.populate_xadrez()
for fila in range(tabuleiro.nrfilas):# verifica para todas as filas aka listas dentro da lista principal
        for coluna in range(tabuleiro.nrcolunas):
                if tabuleiro.list[fila][coluna] != "":
                    tabuleiro.list[fila][coluna].set_pieces() #coloca as peças com o seu sprite correto


#Se o turno é 1, são as brancas a jogar. Se é -1, são as pretas a jogar
turn= 1 
timer_to_change_turn= 200
mostrar_movimento= 1

#se algum peão está a promover
pawn_is_promoting= False
fila_promotion= 0
coluna_promotion= 0
promoted= False

#Temporizadores de cada jogador
clock = pygame.time.Clock()
white_p_name= "White Bozo"
black_p_name= "Black Bozo"
#em segundos
Timer_white= 600
Timer_black= 600
#timers ligados <=> Timer_on= True
Timer_on= True
tempo_passado= 0
game_ended_by_time= False
game_ended_by_checkmate= False

undo_tabuleiro= []

running=True
while running:
    screen.fill(preto)
    
    clock.tick()

    screen.blit(background_sprite,postabuleiro) #mostra a imagem do tabuleiro
    
    for fila in range(tabuleiro.nrfilas):# verifica para todas as filas aka listas dentro da lista principal
        for coluna in range(tabuleiro.nrcolunas):
            if tabuleiro.list[fila][coluna] != "":
                tabuleiro.list[fila][coluna].set_pos( tradutor_lista_coordreal(coluna+1, fila+1) ) #definir a nova posição através da função do tradutor
                if tabuleiro.list[fila][coluna].is_selected: #se a peça está selecionada
                    tabuleiro.list[fila][coluna].selected() #função q mostra q a peça está selecionada
                tabuleiro.list[fila][coluna].draw() #mostra a peça no ecrã
                    
                #se n for o turno de essa peça jogar, ela deixa de poder ser selecionada
                if (turn < 0 and tabuleiro.list[fila][coluna].team == "white") or (turn > 0 and tabuleiro.list[fila][coluna].team != "white"):
                    tabuleiro.list[fila][coluna].selectable= False
                #se for o seu turno, a peça passa a poder ser selecionada
                elif (turn > 0 and tabuleiro.list[fila][coluna].team == "white") or (turn < 0 and tabuleiro.list[fila][coluna].team != "white"):
                    tabuleiro.list[fila][coluna].selectable= True

                if tabuleiro.list[fila][coluna].tipo == "Peao": #se for um peão
                    if tabuleiro.list[fila][coluna].check_promotion(): #verifica se está na ultima posição para promover para uma peça nova
                        show_possible_promotions() #mostrar as possiveis promoções no ecrã
                        pawn_is_promoting= True
                        #guardar a posição do peão q está a promover
                        fila_promotion= fila
                        coluna_promotion= coluna

                if tabuleiro.list[fila][coluna].tipo == "Rei": #se for um rei
                    is_in_check= tabuleiro.list[fila][coluna].check_checks(tabuleiro.list, fila, coluna)
                    if is_in_check == "check": #se estiver em check
                        tabuleiro.list[fila][coluna].in_check = True
                        king_check() #mostra o "Check"
                        #if tabuleiro.check_checkmate(fila, coluna) == "checkmate":
                            #game_ended_by_checkmate= True
                            #if tabuleiro.list[fila][coluna].team == "white":
                               # king_in_checkmate= "black"
                            #else:
                               # king_in_checkmate= "white"
                    else:
                        tabuleiro.list[fila][coluna].in_check = False
    
    #tirar o tempo passado entre frames a cada jogador para simular o tempo real gasto
    if Timer_on:
        tempo_passado = clock.get_rawtime() / 1000 #a função faz return em milisegundos logo para termos segundos dividimos por mil
        if not game_ended_by_time:
            if Timer_black <= 0:
                game_ended_by_time = True
                team_who_won = "White"

            elif Timer_white <= 0:
                game_ended_by_time = True
                team_who_won = "Black"
        #mostrar os temporizadores de cada jogador, se o Timer_on for True
        Render_Text(show_timer(Timer_white), white, (postabuleiro[0], postabuleiro[1] + 8*tamquadricula), white_p_name + ": ", 30)
        Render_Text(show_timer(Timer_black), white, (postabuleiro[0], postabuleiro[1]-30), black_p_name + ": ", 30)

    if turn > 0:
        whose_turn= "White"
        if not game_ended_by_time:
            Timer_white -= tempo_passado
    else:
        whose_turn= "Black"
        if not game_ended_by_time:
            Timer_black -= tempo_passado
        
    #mostra a vez de quem é a jogar
    Render_Text(whose_turn, white, (postabuleiro[0] + 4.5*tamquadricula, postabuleiro[1]-30), "Turn to play: ", 30)
    
    #detetar se alguma tecla está a ser pressionada
    key1= pygame.key.get_pressed()
    
    #se carregar no ENTER, é para trocar o turno de quem é a jogar
    if (key1[pygame.K_KP_ENTER] or key1[pygame.K_RETURN]) and timer_to_change_turn == 0:
        turn*=-1 #muda o turno
        timer_to_change_turn= 200
        
    #isto serve só para ser mais fácil de trocar o turno, no sentido de se poder estar mais tempo a carregar no botão
    if not timer_to_change_turn == 0:
        timer_to_change_turn-=1

    if pawn_is_promoting: #se há um peão a promover para uma peça nova
        if tabuleiro.list[fila_promotion][coluna_promotion].team == "white":
            teampromoting= "white"
        else:
            teampromoting= "black"

        if key1[pygame.K_q]:
            tabuleiro.list[fila_promotion][coluna_promotion]= Rainha(screen, (0,0), 40, "Rainha", teampromoting)
            promoted= True
        elif key1[pygame.K_r]:
            tabuleiro.list[fila_promotion][coluna_promotion]= Torre(screen, (0,0), 40, "Torre", teampromoting)
            promoted= True
        elif key1[pygame.K_h]:
            tabuleiro.list[fila_promotion][coluna_promotion]= Cavalo(screen, (0,0), 40, "Cavalo", teampromoting)
            promoted= True
        elif key1[pygame.K_b]:
            tabuleiro.list[fila_promotion][coluna_promotion]= Bispo(screen, (0,0), 40, "Bispo", teampromoting)
            promoted= True
        
        if promoted:
            tabuleiro.list[fila_promotion][coluna_promotion].set_pieces()
            pawn_is_promoting= False
    
    #verificar se a jogada é legal
    if tabuleiro.check_if_king_in_check(tabuleiro.list) != False: #se estiverem a haver um check
        if tabuleiro.check_if_king_in_check(tabuleiro.list) == tabuleiro.check_if_king_in_check(undo_tabuleiro) \
        and ( (tabuleiro.check_if_king_in_check(tabuleiro.list) == "white" and turn < 0) \
        or (tabuleiro.check_if_king_in_check(tabuleiro.list) == "black" and turn > 0) ):
            #se houve um check na jogada passada e agora também está a existir o mesmo 
            # E! se o branco ou o preto tiverem mexido uma peça q n parou o check,
            print("movimento ilegal")
            empty_space= tabuleiro.get_emptyspace()
            tabuleiro.piece_move([filaselecionada, colunaselecionada], empty_space, peca.tipo) #colocar o tabuleiro de novo com estava na jogada anterior
            tabuleiro.list[filaselecionada][colunaselecionada]= piece_taken
            tabuleiro.piece_move(empty_space, [fila_moved,coluna_moved], peca.tipo)
            turn*= -1

    for event in pygame.event.get():
       if event.type==pygame.QUIT:
           running=False
       elif event.type == pygame.KEYUP:
           pass
       elif event.type == pygame.MOUSEBUTTONDOWN and event.button==1: #carregou com o botão esquerdo
           mouse_pos= mousepos()
           for fila in range(tabuleiro.nrfilas): #verifica para todas as filas aka listas dentro da lista principal
               for coluna in range(tabuleiro.nrcolunas):
                   peca= tabuleiro.list[fila][coluna] #peca naquela quadricula especifica
                   if peca != "":
                       if peca.check_if_selected(mouse_pos) and peca.selectable:
                           #verifica se o rato está a selecionar a peça e se a mesma pode ser selecionada
                           peca.is_selected= True
           
                       elif peca.is_selected:
                            #calcular a posição em q o rato está a carregar
                            colunaselecionada, filaselecionada = posicao_in_tabuleiro(tamquadricula, postabuleiro, mouse_pos)
                            #conversão em coordenadas de lista
                            filaselecionada-=1
                            colunaselecionada-=1

                            #peça q se está a mexer está nesta posição
                            fila_moved = fila
                            coluna_moved = coluna
                            
                            try:
                                mudar_turno, piece_taken= tabuleiro.xadrez_move([fila,coluna], [filaselecionada, colunaselecionada], peca.tipo)
                            except TypeError:
                                mudar_turno = tabuleiro.xadrez_move([fila,coluna], [filaselecionada, colunaselecionada], peca.tipo)
                            
                            peca.is_selected= False
                            fila_moved = fila
                            coluna_moved = coluna
                            if mudar_turno:
                                turn*=-1
                                #mostra o tabuleiro na consola
                                undo_tabuleiro = mostrar_tabuleiro_na_consola(tabuleiro.list)

    #mostra q o jogo acabou
    if game_ended_by_time:
        endscreen_by_time(team_who_won)
    #elif game_ended_by_checkmate:
        #endscreen_by_checkmate(king_in_checkmate)
        
        
    pygame.display.update()
    
pygame.quit()