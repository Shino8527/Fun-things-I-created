# -*- coding: utf-8 -*-
import pygame

class Peca_xadrez:
    def __init__(self, screen, pos, size, tipo, team):
        self.screen= screen
        self.pos= pos
        self.tipo= tipo
        self.team= team
        self.size= size
        self.pecabranca= 0
        self.pecapreta= 0
        self.is_selected= False
        self.color= (0,255,0) #cor de estar selecionado
        self.hitbox= pygame.Rect(0 , 0, size, size)
        self.hitbox.center= (pos[0],pos[1])
        self.selectable= True
    
        
    def draw(self): #desenhar a peça, de acordo com o seu tipo e equipa
        if self.team=="white":
            self.screen.blit(self.pecabranca, self.hitbox)
        else:
            self.screen.blit(self.pecapreta, self.hitbox)
                
    def set_state(self, what):
        self.state= what
    
    def get_pos(self):
        return self.pos
    
    def set_pos(self, posicaofinal):
        self.hitbox.center= posicaofinal
        self.pos= posicaofinal
    
    def check_if_selected(self, mouse_pos):
        mouse= pygame.Rect(0 , 0, 1, 1)
        mouse.center= mouse_pos
        if pygame.Rect.colliderect(self.hitbox, mouse):
            return True
        else: 
            return False
        
    def selected(self): #mostra q está selecionada
        pygame.draw.rect(self.screen, self.color, self.hitbox)