# -*- coding: utf-8 -*-
import pygame
import math
import copy
from Peça import *
from Tabuleiro import *

pygame.init()
pygame.display.set_caption("Damas")

background_sprite= pygame.image.load("Board.jpg")

def mousepos():
    return pygame.mouse.get_pos()

def Render_Text(what, color, where, additional_text): #mostra o q for na srceen
    font = pygame.font.Font('freesansbold.ttf', 30)
    text = font.render(additional_text+what, 1, color)
    screen.blit(text, where)            
    
def tradutor_lista_coordreal(coluna, fila):
    #print(coluna, fila)
    #calcular as coordenadas reais no tabuleiro
    coluna*= tamquadricula
    coluna+= postabuleiro[0]- tamquadricula/2
    fila*= tamquadricula
    fila+= postabuleiro[1]- tamquadricula/2
    
    coluna= math.floor(coluna)
    fila= math.floor(fila)
    
    #print(coluna, fila)
    return [coluna,fila]

def distancia_pontos(p1,p2):
    distancia= math.sqrt( (p1[0]-p2[0])**2 + (p1[1]-p2[1])**2)
    return distancia

def posicao_in_tabuleiro(tamquadricula, postabuleiro, mouse_pos):
    #definir exatamente em q quadricula é q o rato está
    x, y= mouse_pos[0]-postabuleiro[0] , mouse_pos[1]-postabuleiro[1]
    
    coluna= math.floor(x/tamquadricula)
    if x%tamquadricula > 0:
        coluna+=1
    
    fila= math.floor(y/tamquadricula)
    if  y%tamquadricula > 0:
        fila+=1
     
    return [coluna,fila]

def all_eliminated_1team(lista):
    team_branca=0
    team_preta=0
    for fila in range(8):# verifica para todas as filas aka listas dentro da lista principal
        for coluna in range(8):
            if tabuleiro.list[fila][coluna] != "":
                if tabuleiro.list[fila][coluna].team == "white":
                    team_branca+=1
                else:
                    team_preta+=1
    if team_branca == 0 or team_preta == 0:
        return True
    else:
        return False
    
def endscreen():
    Render_Text("Jogo acabou!", preto, (midx-100, midy), "")
    
#fullscreen, alt+f4 para sair
ScreenWidth= 832
ScreenHeight= 800
midx= round(ScreenWidth/2)
midy= round(ScreenHeight/2)
screen= pygame.display.set_mode((ScreenWidth,ScreenHeight))

preto=(0,0,0)
white=(255,255,255)

postabuleiro= (100,100)
tamquadricula= 79
tabuleiro= Tabuleiro(screen, 8, 8, tamquadricula, postabuleiro)
tabuleiro.populate_damas()

list_of_movements= [tabuleiro]

#Se o turno é 1, são as brancas a jogar. Se é -1, são as pretas a jogar
turn= 1 
timer_to_change_turn= 200
mostrar_movimento= 1
timer_to_change_movement=200

game_ended= False

running=True
while running:
    screen.fill(preto)
    
    screen.blit(background_sprite,postabuleiro) #mostra a imagem do tabuleiro
    
    for fila in range(tabuleiro.nrfilas):# verifica para todas as filas aka listas dentro da lista principal
        for coluna in range(tabuleiro.nrcolunas):
            if tabuleiro.list[fila][coluna] != "":
                tabuleiro.list[fila][coluna].set_pos( tradutor_lista_coordreal(coluna+1, fila+1) ) #definir a nova posição através da função do tradutor
                if tabuleiro.list[fila][coluna].is_selected:
                    tabuleiro.list[fila][coluna].selected() #função q mostra q a peça está selecionada
                tabuleiro.list[fila][coluna].draw() #mostra a peça no ecrã
                if tabuleiro.list[fila][coluna].check_promotion():
                    tabuleiro.list[fila][coluna].set_state("dama")
                    
                #se n for o turno de essa peça jogar, ela deixa de poder ser selecionada
                if (turn < 0 and tabuleiro.list[fila][coluna].team == "white") or (turn > 0 and tabuleiro.list[fila][coluna].team != "white"):
                    tabuleiro.list[fila][coluna].selectable= False
                #se for o seu turno, a peça passa a poder ser selecionada
                elif (turn > 0 and tabuleiro.list[fila][coluna].team == "white") or (turn < 0 and tabuleiro.list[fila][coluna].team != "white"):
                    tabuleiro.list[fila][coluna].selectable= True
                    
    if all_eliminated_1team(tabuleiro.list):
        game_ended= True
    
    if turn > 0:
        whose_turn= "White"
    else:
        whose_turn= "Black"
        
    #mostra a vez de quem é a jogar
    Render_Text(whose_turn, white, (postabuleiro[0], postabuleiro[1]-50), "Turn to play: ")
    
    #detetar se alguma tecla está a ser pressionada
    key1= pygame.key.get_pressed()
    
    #se carregar no ENTER, é para trocar o turno de quem é a jogar
    if (key1[pygame.K_KP_ENTER] or key1[pygame.K_RETURN]) and timer_to_change_turn == 0:
        turn*=-1 #muda o turno
        timer_to_change_turn= 200
        if tabuleiro.list not in list_of_movements:
            list_of_movements.append(copy.copy(tabuleiro))
            mostrar_movimento+=1
    
    #isto serve só para ser mais fácil de trocar o turno, no sentido de se poder estar mais tempo a carregar no botão
    if not timer_to_change_turn == 0:
        timer_to_change_turn-=1
    
    if not timer_to_change_movement == 0:
        timer_to_change_movement-=1
        
    if key1[pygame.K_LEFT] and mostrar_movimento-1 >= 0 and timer_to_change_movement == 0:
        mostrar_movimento-=1
        timer_to_change_movement=200
        tabuleiro.list= list_of_movements[mostrar_movimento].list
        print("mostrei a jogada anterior")
        
    elif key1[pygame.K_RIGHT] and mostrar_movimento+1 < len(list_of_movements) and timer_to_change_movement == 0:
        mostrar_movimento+=1
        timer_to_change_movement=200
        tabuleiro.list= list_of_movements[mostrar_movimento].list
        print("mostrei a próxima jogada")
        
    for event in pygame.event.get():
       if event.type==pygame.QUIT:
           running=False
       elif event.type == pygame.KEYUP:
           pass
       elif event.type == pygame.MOUSEBUTTONDOWN and event.button==1: #carregou com o botão esquerdo
           mouse_pos= mousepos()
           for fila in range(tabuleiro.nrfilas):# verifica para todas as filas aka listas dentro da lista principal
               for coluna in range(tabuleiro.nrcolunas):
                   peca= tabuleiro.list[fila][coluna] #peca naquela quadricula especifica
                   if peca== "":
                       pass
                   else:
                       if peca.check_if_selected(mouse_pos) and peca.selectable: #verifica se o rato está a selecionar a peça
                           peca.is_selected= True
           
                       elif peca.is_selected:
                           #calcular a posição em q o rato está a carregar
                           colunaselecionada, filaselecionada = posicao_in_tabuleiro(tamquadricula, postabuleiro, mouse_pos)
                           
                           #calcular as coordenadas reais no ecrã para a peça
                           square= tradutor_lista_coordreal(colunaselecionada, filaselecionada)
                           
                           if peca.state== "normal":
                       #print(str(peca.hitbox.center))
                               if ( distancia_pontos(peca.hitbox.center, square) > 1.5*tamquadricula ) \
                               or peca.hitbox.centerx== square[0] or peca.hitbox.centery== square[1]:
                                   peca.is_selected= False
                               else:
                                   peca.is_selected= False
                                   #tradução para posições nas listas
                                   filaselecionada-=1
                                   colunaselecionada-=1
                                   
                                   tabuleiro.dama_move([fila,coluna], [filaselecionada, colunaselecionada], "normal")
                                   turn*=-1
                           else:
                               if peca.hitbox.centerx== square[0] or peca.hitbox.centery== square[1]:
                                   peca.is_selected= False
                               else:
                                 peca.is_selected= False 
                                 #tradução para posições nas listas
                                 filaselecionada-=1
                                 colunaselecionada-=1
                                 
                                 tabuleiro.dama_move([fila, coluna], [filaselecionada, colunaselecionada], "big peça")
                                 turn*=-1
    #mostra q o jogo acabou
    if game_ended:
        endscreen()
        
        
    pygame.display.update()
    
pygame.quit()