#Pong
import pygame
pygame.init()
pygame.display.set_caption("Pong")

#sons
ponto=pygame.mixer.Sound("message-incoming-132126.mp3")
hit=pygame.mixer.Sound("chopping-wood-96709.mp3")

def som(nr):
    if nr==0:
        pygame.mixer.Sound.play(hit)
    if nr==1:
        pygame.mixer.Sound.play(ponto)
    
ScreenWidth= 1500
ScreenHeight= 750
midx= round(ScreenWidth/2)
midy= round(ScreenHeight/2)
screen= pygame.display.set_mode((ScreenWidth,ScreenHeight))

tamanho=150
player1= pygame.Rect(50,midy-tamanho/2,10,tamanho)
player2= pygame.Rect(ScreenWidth-50,midy-tamanho/2,10,tamanho)
velbarras=1

#ball
x=500
y=midy
raio= 20
diam= raio*2
aumxi=-1
aumyi=-1
aumx= aumxi
aumy= aumyi
ball= pygame.Rect(x-raio,y-raio,diam,diam)

#limite de bounces, quando bounces=limite a velocidade da bola aumenta
limite=10
bounces=0

#pontuações
pts1=0
pts2=0
font=pygame.font.Font('freesansbold.ttf',40)
golo=False

#cores
cor1=(0,255,0)
cor2=(255,0,0)
corball=(0,0,255)
preto=(0,0,0)
branco=(255,255,255)

run= True
while run:
    
    screen.fill(preto)
    
    text=font.render(str(pts1)+"      "+str(pts2),True,branco,preto)
    textRect=text.get_rect()
    textRect.center=(midx,midy)

    screen.blit(text,textRect)
    
    pygame.draw.circle(screen,corball,(x,y),raio)
    pygame.draw.rect(screen,cor1,player1)
    pygame.draw.rect(screen,cor2,player2)
    
    key1= pygame.key.get_pressed()

    if key1[pygame.K_w]:
        player1.move_ip(0,-velbarras)
    elif key1[pygame.K_s]:
        player1.move_ip(0,velbarras)
          
    if key1[pygame.K_UP]:
        player2.move_ip(0,-velbarras)
    elif key1[pygame.K_DOWN]:
        player2.move_ip(0,velbarras)
    
    x+=aumx
    y+=aumy
    ball.move_ip(aumx,aumy)
   
    if x-raio<=0:#lado esquerdo
        som(1)
        pts2+=1
        x=midx
        y=midy
        ball= pygame.Rect(x-raio,y-raio,diam,diam)
        bounces=0
        golo=True
    
    if x+raio>=ScreenWidth:#lado direito
        som(1)
        pts1+=1
        x=midx
        y=midy
        ball= pygame.Rect(x-raio,y-raio,diam,diam)
        bounces=0
        golo=True
        
    if y-raio<=0 or y+raio>=ScreenHeight:#cima ou baixo
        som(0)
        aumy*=-1 
        bounces+=1
        
    if bounces>=limite:
        aumx*=2
        aumy*=2
        velbarras*=2
        bounces=0
    if golo:
        aumx= aumxi
        aumy= aumyi
        velbarras=1
        golo=False
    
    if pygame.Rect.colliderect(ball,player1) or pygame.Rect.colliderect(ball,player2):
        som(0)
        aumx*=-1
     
    
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    
    pygame.display.update()

pygame.quit()