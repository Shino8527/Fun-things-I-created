import pygame
import math
import random

class Square:
    def __init__(self, screen, squaresize):
        self.screen= screen
        self.bombs_around= 0
        self.is_bomb= False
        self.hitbox= pygame.rect.Rect(0,0, squaresize, squaresize)
        self.image= pygame.image.load("square.jpg")
        self.is_revealed= False
        self.has_flag= -1 
        #-1 significa q n tem
        #1 significa q tem uma bandeira

    def set_size(self, size):
        self.image= pygame.transform.scale(self.image, (size, size))

    def set_image(self, image):
        self.image= pygame.image.load(image)

    def Render_Number(self):
        if self.bombs_around != 0:
            font = pygame.font.Font('freesansbold.ttf', self.hitbox.height)
            text = font.render(str(self.bombs_around), 1, (255,255,255))
            self.screen.blit(text, self.hitbox)

class Matriz:
    def __init__(self, screen, height, lenght, squaresize, nrbombs):
        self.screen= screen
        self.height= height
        self.lenght= lenght
        self.squaresize= squaresize
        self.nrbombs= nrbombs
        self.matriz= []
        self.rows= math.floor(lenght/squaresize)
        self.columns= math.floor(height/squaresize)
        self.lst_around=  [(1,0),(1,1),(0,1),(1,-1),(-1,0),(-1,1),(0,-1),(-1,-1)]
        for row in range(self.rows):
            line= []
            for column in range(self.columns):
                line.append(Square(self.screen, self.squaresize))
            self.matriz.append(line)

    def define_matriz(self):
        for row in range(len(self.matriz)):
            for column in range(len(self.matriz[row])):
                bloco= self.matriz[row][column]
                bloco.hitbox.top= self.squaresize*column
                bloco.hitbox.left= self.squaresize*row
                
    def draw_matriz(self):
        for row in range(len(self.matriz)):
            for bloco in self.matriz[row]:
                bloco.set_size(self.squaresize)
                if not bloco.is_revealed:
                    if bloco.has_flag > 0:
                        #pygame.draw.rect(self.screen, (255, 0, 0), bloco.hitbox)
                        bloco.set_image("flag.jpg")
                    else:
                        bloco.set_image("square.jpg")
                    self.screen.blit(bloco.image, bloco.hitbox)
                else:
                    bloco.Render_Number()

    def get_number_revealed(self):
        nr_revealed= 0
        for row in range(len(self.matriz)):
            for bloco in self.matriz[row]:
                if bloco.is_revealed:
                    nr_revealed+=1
        return nr_revealed

    def get_square(self):
        mouse_pos1= mouse_pos()
        x, y= mouse_pos1[0] , mouse_pos1[1]
        
        coluna= math.floor(x/self.squaresize)
        if x%self.squaresize > 0:
            coluna+=1
        
        fila= math.floor(y/self.squaresize)
        if  y%self.squaresize > 0:
            fila+=1
        return [coluna-1,fila-1]
    
    def placed_flag(self):
        pos= self.get_square()
        bloco= self.matriz[pos[0]][pos[1]]
        if not bloco.is_revealed:
            bloco.has_flag*= -1
            if bloco.has_flag > 0:
                display.flags-=1
            else:
                display.flags+=1

    
    def square_hit(self):
        pos= self.get_square()
        bloco= self.matriz[pos[0]][pos[1]]
        if bloco.has_flag < 0: #se n tiver uma flag
            bloco.is_revealed= True
            if bloco.bombs_around == 0:
                self.reveal_around_0(pos[0], pos[1])
            return bloco.is_bomb

    def reveal_around_0(self, row, column):
        for item in range(8):
            try:
                evaluated_row= row + self.lst_around[item][0]
                evaluated_column= column + self.lst_around[item][1]
                bloco= self.matriz[evaluated_row][evaluated_column]
                if evaluated_row < 0 or evaluated_column < 0: 
                    #se a pos escolhida for negativa, a lista vai contar outra posição a partir do fim da lista
                    pass
                elif bloco.has_flag < 0: #se o bloco n tiver uma flag
                    if bloco.bombs_around == 0 and not bloco.is_revealed:
                        self.matriz[evaluated_row][evaluated_column].is_revealed= True
                        self.reveal_around_0(evaluated_row, evaluated_column)
                    elif bloco.bombs_around != 0 and not bloco.is_revealed:
                        self.matriz[evaluated_row][evaluated_column].is_revealed= True

            except:
                pass


    def set_bombs(self):
        for bomb in range(self.nrbombs):
            c= True
            while c:
                place= self.matriz[random.randint(0, self.rows-1)][random.randint(0, self.columns-1)]
                if not place.is_bomb:
                    place.is_bomb= True
                    c= False

        for row in range(len(self.matriz)):
            for column in range(len(self.matriz[row])):
                if self.matriz[row][column].is_bomb:
                    self.matriz[row][column].bombs_around="O"
                else:
                    self.check_around(row, column)
                
    def check_around(self, row, column):#esta função atualiza os blocos para estes mostrarem quantas bombas têm à volta
        for item in range(8):
            try:
                evaluated_row= row + self.lst_around[item][0]
                evaluated_column= column + self.lst_around[item][1]
                if evaluated_row < 0 or evaluated_column < 0: 
                    #se a pos escolhida for negativa, a lista vai contar outra posição a partir do fim da lista
                    pass
                elif self.matriz[evaluated_row][evaluated_column].is_bomb: 
                    #se houver uma bomba à sua volta, soma +1 à variável q conta quantas bombas o bloco tem á sua volta
                    self.matriz[row][column].bombs_around+=1
            except:
                pass

class Display:
    def __init__(self, screen, nrbombs):
        self.screen= screen
        self.nrbombs= nrbombs
        self.flags= nrbombs

    def draw(self):
        if self.flags < 0:
            txt= "0"
        else:
            txt= str(self.flags)
        font = pygame.font.Font('freesansbold.ttf', 100)
        text = font.render(txt, 1, (0,255,0))
        self.screen.blit(text, (20,20))

    def add_flag(self):
        self.flags+=1

def mouse_pos():
    return pygame.mouse.get_pos()

def game_ended(txt):
    hitbox= pygame.rect.Rect(midx-320, midy-100, 540, 100)
    font = pygame.font.Font('freesansbold.ttf', 100)
    text = font.render("Game "+ txt, 1, (255,255,255))
    pygame.draw.rect(screen, preto, hitbox)
    screen.blit(text, hitbox)

pygame.init()
pygame.display.set_caption("Minesweeper")

#fullscreen, alt+f4 para sair
ScreenWidth= 800
ScreenHeight= 600
midx= round(ScreenWidth/2)
midy= round(ScreenHeight/2)
screen= pygame.display.set_mode((ScreenWidth,ScreenHeight))

preto=(0,0,0)
nrbombas= 10
matriz= Matriz(screen, ScreenHeight, ScreenWidth, 100, nrbombas)
matriz.define_matriz()
matriz.set_bombs()
nrsquares= matriz.rows*matriz.columns
flag_delay= 0

display= Display(screen, nrbombas)

mouse_down= False
game_lost= False
game_won= False

running=True
while running:
    screen.fill(preto)

    matriz.draw_matriz() #desenha a matriz e faz return do nr de flags já colocadas

    display.draw()

    if flag_delay > 0:
        flag_delay-= 1
    
    if mouse_down:
        if eventbutton == 1:
            if matriz.square_hit(): #se tiver acertado numa bomba a função faz "return True"
                game_lost= True
            if matriz.get_number_revealed() == nrsquares-nrbombas:
                game_won= True
        elif eventbutton == 2 and flag_delay == 0:
            matriz.placed_flag()
            flag_delay= 30

    for event in pygame.event.get():
       if event.type==pygame.QUIT:
           running=False
       elif event.type == pygame.KEYUP:
           pass
       elif event.type == pygame.MOUSEBUTTONUP:
           mouse_down= False
       elif event.type == pygame.MOUSEBUTTONDOWN and event.button==1: #carregou com o botão esquerdo
           mouse_down= True
           eventbutton= 1
       elif event.type == pygame.MOUSEBUTTONDOWN and event.button==3: #carregou com o botão direito
           mouse_down= True
           eventbutton= 2

    if game_lost:
        game_ended("Lost")
    elif game_won:
        game_ended("Won")
    
    pygame.display.update()
    
pygame.quit()